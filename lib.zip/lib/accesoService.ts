import { supabase } from "@/lib/supabase";

export interface AuditoriaLog {
  id: number;
  usuario_nombre: string;
  tabla_afectada: string;
  operacion: string;
  registro_id: number;
  datos_anteriores?: any;
  datos_nuevos?: any;
  cambios?: any;
  fecha_acceso: string;
  hora_acceso: string;
  detalles?: string;
  created_at: string;
}

export interface FiltrosAuditoria {
  usuario?: string;
  tabla?: string;
  operacion?: string;
  fecha?: string;
  limite?: number;
  offset?: number;
}

class AuditoriaService {
  /**
   * Obtiene todos los registros de auditoría con filtros opcionales
   */
  async obtenerAuditoria(filtros?: FiltrosAuditoria): Promise<AuditoriaLog[]> {
    try {
      let query = supabase
        .from("auditoria_bd")
        .select("*", { count: "exact" });

      // Aplicar filtros
      if (filtros?.usuario) {
        query = query.ilike("usuario_nombre", `%${filtros.usuario}%`);
      }

      if (filtros?.tabla) {
        query = query.eq("tabla_afectada", filtros.tabla);
      }

      if (filtros?.operacion) {
        query = query.eq("operacion", filtros.operacion);
      }

      if (filtros?.fecha) {
        query = query.eq("fecha_acceso", filtros.fecha);
      }

      // Ordenar por más reciente
      query = query.order("created_at", { ascending: false });

      // Paginación
      const offset = filtros?.offset || 0;
      const limite = filtros?.limite || 100;
      query = query.range(offset, offset + limite - 1);

      const { data, error } = await query;

      if (error) {
        console.error("Error obteniendo auditoría:", error);
        return [];
      }

      return data || [];
    } catch (err) {
      console.error("Error en obtenerAuditoria:", err);
      return [];
    }
  }

  /**
   * Obtiene auditoría de una tabla específica
   */
  async obtenerAuditoriaTabla(
    tabla: "usuarios" | "garantias",
    filtros?: Omit<FiltrosAuditoria, "tabla">
  ): Promise<AuditoriaLog[]> {
    return this.obtenerAuditoria({
      ...filtros,
      tabla,
    });
  }

  /**
   * Obtiene auditoría de un usuario específico
   */
  async obtenerAuditoriaUsuario(
    usuario: string,
    filtros?: Omit<FiltrosAuditoria, "usuario">
  ): Promise<AuditoriaLog[]> {
    return this.obtenerAuditoria({
      ...filtros,
      usuario,
    });
  }

  /**
   * Obtiene auditoría de una operación específica
   */
  async obtenerAuditoriaOperacion(
    operacion: "INSERT" | "UPDATE" | "DELETE" | "SELECT",
    filtros?: Omit<FiltrosAuditoria, "operacion">
  ): Promise<AuditoriaLog[]> {
    return this.obtenerAuditoria({
      ...filtros,
      operacion,
    });
  }

  /**
   * Obtiene auditoría de una fecha específica
   */
  async obtenerAuditoriaFecha(
    fecha: string,
    filtros?: Omit<FiltrosAuditoria, "fecha">
  ): Promise<AuditoriaLog[]> {
    return this.obtenerAuditoria({
      ...filtros,
      fecha,
    });
  }

  /**
   * Obtiene el historial completo de un registro específico
   */
  async obtenerHistorialRegistro(
    tabla: "usuarios" | "garantias",
    recordId: number
  ): Promise<AuditoriaLog[]> {
    try {
      const { data, error } = await supabase
        .from("auditoria_bd")
        .select("*")
        .eq("tabla_afectada", tabla)
        .eq("registro_id", recordId)
        .order("created_at", { ascending: true });

      if (error) {
        console.error("Error obteniendo historial:", error);
        return [];
      }

      return data || [];
    } catch (err) {
      console.error("Error en obtenerHistorialRegistro:", err);
      return [];
    }
  }

  /**
   * Obtiene estadísticas de auditoría
   */
  async obtenerEstadisticas(fecha?: string): Promise<any> {
    try {
      let query = supabase.from("auditoria_bd").select("*");

      if (fecha) {
        query = query.eq("fecha_acceso", fecha);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Error obteniendo estadísticas:", error);
        return null;
      }

      // Procesar datos
      const stats = {
        total: data?.length || 0,
        porOperacion: {} as Record<string, number>,
        porUsuario: {} as Record<string, number>,
        porTabla: {} as Record<string, number>,
        usuariosUnicos: new Set(data?.map((d) => d.usuario_nombre)).size,
      };

      // Contar por operación
      data?.forEach((item) => {
        stats.porOperacion[item.operacion] =
          (stats.porOperacion[item.operacion] || 0) + 1;
        stats.porUsuario[item.usuario_nombre] =
          (stats.porUsuario[item.usuario_nombre] || 0) + 1;
        stats.porTabla[item.tabla_afectada] =
          (stats.porTabla[item.tabla_afectada] || 0) + 1;
      });

      return stats;
    } catch (err) {
      console.error("Error en obtenerEstadisticas:", err);
      return null;
    }
  }

  /**
   * Obtiene actividad reciente (últimas 24 horas)
   */
  async obtenerActividadReciente(horas: number = 24): Promise<AuditoriaLog[]> {
    try {
      const fecha = new Date();
      fecha.setHours(fecha.getHours() - horas);

      const { data, error } = await supabase
        .from("auditoria_bd")
        .select("*")
        .gte("created_at", fecha.toISOString())
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error obteniendo actividad reciente:", error);
        return [];
      }

      return data || [];
    } catch (err) {
      console.error("Error en obtenerActividadReciente:", err);
      return [];
    }
  }

  /**
   * Obtiene usuarios más activos
   */
  async obtenerUsuariosMasActivos(limite: number = 10): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from("auditoria_bd")
        .select("usuario_nombre, COUNT(*) as total")
        .order("total", { ascending: false })
        .limit(limite);

      if (error) {
        console.error("Error obteniendo usuarios activos:", error);
        return [];
      }

      return data || [];
    } catch (err) {
      console.error("Error en obtenerUsuariosMasActivos:", err);
      return [];
    }
  }

  /**
   * Exporta auditoría a formato texto/CSV
   */
  formatoCSV(auditorias: AuditoriaLog[]): string {
    const headers = [
      "ID",
      "Usuario",
      "Tabla",
      "Operación",
      "Fecha",
      "Hora",
      "Detalles",
      "Registro ID",
    ];

    const rows = auditorias.map((a) => [
      a.id,
      a.usuario_nombre,
      a.tabla_afectada,
      a.operacion,
      a.fecha_acceso,
      a.hora_acceso,
      a.detalles || "",
      a.registro_id || "",
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((r) => r.map((v) => `"${v}"`).join(",")),
    ].join("\n");

    return csv;
  }

  /**
   * Obtiene resumen ejecutivo
   */
  async obtenerResumen(): Promise<any> {
    try {
      const hoy = new Date().toISOString().split("T")[0];

      const { data: hoyData } = await supabase
        .from("auditoria_bd")
        .select("*")
        .eq("fecha_acceso", hoy);

      const { data: todoData } = await supabase
        .from("auditoria_bd")
        .select("*");

      const stats = {
        hoy: {
          total: hoyData?.length || 0,
          inserts: hoyData?.filter((d) => d.operacion === "INSERT").length || 0,
          updates: hoyData?.filter((d) => d.operacion === "UPDATE").length || 0,
          deletes: hoyData?.filter((d) => d.operacion === "DELETE").length || 0,
        },
        general: {
          total: todoData?.length || 0,
          inserts:
            todoData?.filter((d) => d.operacion === "INSERT").length || 0,
          updates:
            todoData?.filter((d) => d.operacion === "UPDATE").length || 0,
          deletes:
            todoData?.filter((d) => d.operacion === "DELETE").length || 0,
          usuariosUnicos: new Set(todoData?.map((d) => d.usuario_nombre)).size,
        },
      };

      return stats;
    } catch (err) {
      console.error("Error en obtenerResumen:", err);
      return null;
    }
  }
}

export default new AuditoriaService();
