import { View, Text, StyleSheet, Pressable, ScrollView, TextInput, FlatList, Modal, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { useState, useEffect } from "react";
import auditoriaService, { AuditoriaLog } from "@/lib/accesoService";

export default function ControlAccesosScreen() {
  const router = useRouter();
  const [usuarioActual, setUsuarioActual] = useState<any>(null);
  const [esAdminOGerente, setEsAdminOGerente] = useState(false);

  const [accesos, setAccesos] = useState<AuditoriaLog[]>([]);
  const [accesosFiltrados, setAccesosFiltrados] = useState<AuditoriaLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [estadisticas, setEstadisticas] = useState<any>(null);

  // Filtros
  const [filtroUsuario, setFiltroUsuario] = useState("");
  const [filtroTabla, setFiltroTabla] = useState<"" | "usuarios" | "garantias">("");
  const [filtroOperacion, setFiltroOperacion] = useState("");
  const [filtroFecha, setFiltroFecha] = useState("");

  // Modal para detalles
  const [modalVisible, setModalVisible] = useState(false);
  const [accesoSeleccionado, setAccesoSeleccionado] = useState<AuditoriaLog | null>(null);

  useEffect(() => {
    const usuario = sessionStorage.getItem("usuarioActual");
    if (usuario) {
      const parsed = JSON.parse(usuario);
      setUsuarioActual(parsed);
      const esPermitido = parsed.rol === "admin" || parsed.rol === "gerente";
      setEsAdminOGerente(esPermitido);

      if (esPermitido) {
        cargarDatos();
      }
    }
  }, []);

  const cargarDatos = async () => {
    try {
      setLoading(true);
      const datos = await auditoriaService.obtenerAuditoria({ limite: 500 });
      setAccesos(datos);
      setAccesosFiltrados(datos);

      const stats = await auditoriaService.obtenerEstadisticas();
      setEstadisticas(stats);
    } catch (error) {
      console.error("Error cargando datos:", error);
    } finally {
      setLoading(false);
    }
  };

  const aplicarFiltros = async () => {
    try {
      setLoading(true);
      const datos = await auditoriaService.obtenerAuditoria({
        usuario: filtroUsuario || undefined,
        tabla: filtroTabla || undefined,
        operacion: filtroOperacion || undefined,
        fecha: filtroFecha || undefined,
        limite: 500,
      });
      setAccesos(datos);
      setAccesosFiltrados(datos);
    } catch (error) {
      console.error("Error aplicando filtros:", error);
    } finally {
      setLoading(false);
    }
  };

  const limpiarFiltros = () => {
    setFiltroUsuario("");
    setFiltroTabla("");
    setFiltroOperacion("");
    setFiltroFecha("");
    cargarDatos();
  };

  const verDetalles = (acceso: AuditoriaLog) => {
    setAccesoSeleccionado(acceso);
    setModalVisible(true);
  };

  const obtenerColorBadge = (operacion: string) => {
    switch (operacion) {
      case "INSERT":
        return { bgColor: "#f0fdf4", borderColor: "#bbf7d0", textColor: "#15803d" };
      case "UPDATE":
        return { bgColor: "#eff6ff", borderColor: "#bfdbfe", textColor: "#0c4a6e" };
      case "DELETE":
        return { bgColor: "#fef2f2", borderColor: "#fecaca", textColor: "#7f1d1d" };
      case "SELECT":
        return { bgColor: "#fefce8", borderColor: "#fef08a", textColor: "#713f12" };
      default:
        return { bgColor: "#f3f4f6", borderColor: "#d1d5db", textColor: "#374151" };
    }
  };

  const obtenerIconoOperacion = (operacion: string) => {
    switch (operacion) {
      case "INSERT":
        return "➕";
      case "UPDATE":
        return "✏️";
      case "DELETE":
        return "🗑️";
      case "SELECT":
        return "👁️";
      default:
        return "📋";
    }
  };

  if (!esAdminOGerente) {
    return (
      <ScrollView contentContainerStyle={styles.scrollContainer} style={styles.mainBackground}>
        <View style={styles.screen}>
          <View style={styles.card}>
            <Text style={styles.errorTitle}>❌ Acceso Denegado</Text>
            <Text style={styles.errorText}>Solo administradores y gerentes pueden acceder al control de accesos.</Text>
            <Pressable style={({ pressed }) => [styles.backButton, pressed && { opacity: 0.8 }]} onPress={() => router.back()}>
              <Text style={styles.backButtonText}>← Volver</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer} style={styles.mainBackground}>
      <View style={styles.screen}>
        <View style={styles.card}>
          {/* HEADER */}
          <View style={styles.headerSection}>
            <Text style={styles.title}>🔐 Control de Accesos</Text>
            <Text style={styles.subtitle}>Monitorea todas las operaciones en BD</Text>
          </View>

          {/* ESTADÍSTICAS */}
          {estadisticas && (
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <Text style={styles.statIcon}>📊</Text>
                <View style={styles.statContent}>
                  <Text style={styles.statValue}>{estadisticas.total}</Text>
                  <Text style={styles.statLabel}>Total Operaciones</Text>
                </View>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statIcon}>👥</Text>
                <View style={styles.statContent}>
                  <Text style={styles.statValue}>{estadisticas.usuariosUnicos}</Text>
                  <Text style={styles.statLabel}>Usuarios Únicos</Text>
                </View>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statIcon}>➕</Text>
                <View style={styles.statContent}>
                  <Text style={styles.statValue}>{estadisticas.porOperacion["INSERT"] || 0}</Text>
                  <Text style={styles.statLabel}>Inserciones</Text>
                </View>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statIcon}>✏️</Text>
                <View style={styles.statContent}>
                  <Text style={styles.statValue}>{estadisticas.porOperacion["UPDATE"] || 0}</Text>
                  <Text style={styles.statLabel}>Modificaciones</Text>
                </View>
              </View>

              <View style={styles.statCard}>
                <Text style={styles.statIcon}>🗑️</Text>
                <View style={styles.statContent}>
                  <Text style={styles.statValue}>{estadisticas.porOperacion["DELETE"] || 0}</Text>
                  <Text style={styles.statLabel}>Eliminaciones</Text>
                </View>
              </View>
            </View>
          )}

          <View style={styles.divider} />

          {/* FILTROS */}
          <View style={styles.filtrosSection}>
            <Text style={styles.filtroTitle}>🔍 Filtros</Text>

            <View style={styles.filtroRow}>
              <View style={styles.filtroGroup}>
                <Text style={styles.filtroLabel}>Usuario</Text>
                <TextInput
                  style={styles.filtroInput}
                  placeholder="Filtrar usuario"
                  value={filtroUsuario}
                  onChangeText={setFiltroUsuario}
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.filtroGroup}>
                <Text style={styles.filtroLabel}>Fecha</Text>
                <TextInput
                  style={styles.filtroInput}
                  placeholder="YYYY-MM-DD"
                  value={filtroFecha}
                  onChangeText={setFiltroFecha}
                  placeholderTextColor="#999"
                />
              </View>
            </View>

            <View style={styles.filtroRow}>
              <View style={styles.filtroGroup}>
                <Text style={styles.filtroLabel}>Tabla</Text>
                <View style={styles.filterButtonsRow}>
                  <Pressable style={[styles.filterBtn, filtroTabla === "" && styles.filterBtnActive]} onPress={() => setFiltroTabla("")}>
                    <Text style={filtroTabla === "" ? styles.filterBtnTextActive : styles.filterBtnText}>Todas</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.filterBtn, filtroTabla === "usuarios" && styles.filterBtnActive]}
                    onPress={() => setFiltroTabla("usuarios")}
                  >
                    <Text style={filtroTabla === "usuarios" ? styles.filterBtnTextActive : styles.filterBtnText}>Usuarios</Text>
                  </Pressable>
                  <Pressable
                    style={[styles.filterBtn, filtroTabla === "garantias" && styles.filterBtnActive]}
                    onPress={() => setFiltroTabla("garantias")}
                  >
                    <Text style={filtroTabla === "garantias" ? styles.filterBtnTextActive : styles.filterBtnText}>Garantías</Text>
                  </Pressable>
                </View>
              </View>

              <View style={styles.filtroGroup}>
                <Text style={styles.filtroLabel}>Operación</Text>
                <View style={styles.filterButtonsRow}>
                  {["INSERT", "UPDATE", "DELETE", "SELECT"].map((op) => (
                    <Pressable
                      key={op}
                      style={[styles.filterBtn, filtroOperacion === op && styles.filterBtnActive]}
                      onPress={() => setFiltroOperacion(filtroOperacion === op ? "" : op)}
                    >
                      <Text style={filtroOperacion === op ? styles.filterBtnTextActive : styles.filterBtnText}>
                        {op === "INSERT" ? "➕" : op === "UPDATE" ? "✏️" : op === "DELETE" ? "🗑️" : "👁️"}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </View>

            <View style={styles.filtroButtonsContainer}>
              <Pressable style={({ pressed }) => [styles.btnAplicar, pressed && { opacity: 0.85 }]} onPress={aplicarFiltros}>
                <Text style={styles.btnAplicarText}>🔎 Aplicar Filtros</Text>
              </Pressable>
              <Pressable style={({ pressed }) => [styles.btnLimpiar, pressed && { opacity: 0.85 }]} onPress={limpiarFiltros}>
                <Text style={styles.btnLimpiarText}>🔄 Limpiar</Text>
              </Pressable>
            </View>
          </View>

          <View style={styles.divider} />

          {/* TABLA DE ACCESOS */}
          <View style={styles.tablaseccion}>
            <Text style={styles.tablaTitle}>📋 Accesos ({accesosFiltrados.length})</Text>

            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#2563eb" />
                <Text style={styles.loadingText}>Cargando datos...</Text>
              </View>
            ) : accesosFiltrados.length === 0 ? (
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>📭 Sin registros</Text>
              </View>
            ) : (
              <FlatList
                scrollEnabled={false}
                data={accesosFiltrados}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => {
                  const colors = obtenerColorBadge(item.operacion);
                  return (
                    <Pressable style={styles.accesoItem} onPress={() => verDetalles(item)}>
                      <View style={styles.accesoHeader}>
                        <View style={styles.accesoLeftContent}>
                          <Text style={styles.accesoUsuario}>👤 {item.usuario_nombre}</Text>
                          <View style={[styles.badge, { backgroundColor: colors.bgColor, borderColor: colors.borderColor }]}>
                            <Text style={[styles.badgeText, { color: colors.textColor }]}>
                              {obtenerIconoOperacion(item.operacion)} {item.operacion}
                            </Text>
                          </View>
                        </View>
                        <Text style={styles.accesoId}>#{item.id}</Text>
                      </View>

                      <View style={styles.accesoBody}>
                        <Text style={styles.accesoTabla}>📊 {item.tabla_afectada.toUpperCase()}</Text>
                        <Text style={styles.accesoTiempo}>
                          🕐 {item.fecha_acceso} {item.hora_acceso}
                        </Text>
                      </View>

                      <View style={styles.accesoFooter}>
                        <Text style={styles.accesoDetalles} numberOfLines={1}>
                          {item.detalles || "Sin detalles"}
                        </Text>
                      </View>
                    </Pressable>
                  );
                }}
              />
            )}
          </View>

          <Pressable style={({ pressed }) => [styles.backButton, pressed && { opacity: 0.8 }]} onPress={() => router.back()}>
            <Text style={styles.backButtonText}>❌ Volver</Text>
          </Pressable>
        </View>
      </View>

      {/* MODAL DE DETALLES */}
      <Modal visible={modalVisible} transparent={true} animationType="slide" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Pressable style={styles.modalCloseButton} onPress={() => setModalVisible(false)}>
              <Text style={styles.modalCloseText}>✕</Text>
            </Pressable>

            {accesoSeleccionado && (
              <ScrollView style={styles.modalScroll}>
                <Text style={styles.modalTitle}>📋 Detalles del Acceso</Text>

                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>ID</Text>
                  <Text style={styles.modalValue}>#{accesoSeleccionado.id}</Text>
                </View>

                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Usuario</Text>
                  <Text style={styles.modalValue}>{accesoSeleccionado.usuario_nombre}</Text>
                </View>

                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Tabla</Text>
                  <Text style={styles.modalValue}>{accesoSeleccionado.tabla_afectada}</Text>
                </View>

                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Operación</Text>
                  <Text style={styles.modalValue}>{accesoSeleccionado.operacion}</Text>
                </View>

                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Fecha y Hora</Text>
                  <Text style={styles.modalValue}>
                    {accesoSeleccionado.fecha_acceso} {accesoSeleccionado.hora_acceso}
                  </Text>
                </View>

                {accesoSeleccionado.registro_id && (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalLabel}>ID del Registro</Text>
                    <Text style={styles.modalValue}>{accesoSeleccionado.registro_id}</Text>
                  </View>
                )}

                {accesoSeleccionado.detalles && (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalLabel}>Detalles</Text>
                    <Text style={styles.modalValue}>{accesoSeleccionado.detalles}</Text>
                  </View>
                )}

                {accesoSeleccionado.datos_anteriores && (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalLabel}>Datos Anteriores</Text>
                    <Text style={[styles.modalValue, styles.codeText]}>{JSON.stringify(accesoSeleccionado.datos_anteriores, null, 2)}</Text>
                  </View>
                )}

                {accesoSeleccionado.datos_nuevos && (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalLabel}>Datos Nuevos</Text>
                    <Text style={[styles.modalValue, styles.codeText]}>{JSON.stringify(accesoSeleccionado.datos_nuevos, null, 2)}</Text>
                  </View>
                )}

                {accesoSeleccionado.cambios && (
                  <View style={styles.modalSection}>
                    <Text style={styles.modalLabel}>Cambios</Text>
                    <Text style={[styles.modalValue, styles.codeText]}>{JSON.stringify(accesoSeleccionado.cambios, null, 2)}</Text>
                  </View>
                )}
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  mainBackground: {
    flex: 1,
    backgroundColor: "#f1f5f9",
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 40,
  },
  screen: {
    width: "100%",
    maxWidth: 900,
    paddingHorizontal: 20,
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 24,
    padding: 36,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 15,
  },
  headerSection: {
    alignItems: "center",
    marginBottom: 28,
  },
  title: {
    fontSize: 28,
    fontWeight: "900",
    color: "#0f172a",
  },
  subtitle: {
    fontSize: 14,
    color: "#64748b",
    marginTop: 8,
  },
  statsContainer: {
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flexDirection: "row",
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: "#e2e8f0",
    alignItems: "center",
  },
  statIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  statContent: {
    flex: 1,
  },
  statValue: {
    fontSize: 20,
    fontWeight: "700",
    color: "#0f172a",
  },
  statLabel: {
    fontSize: 12,
    color: "#64748b",
    marginTop: 4,
  },
  divider: {
    height: 1,
    backgroundColor: "#e2e8f0",
    marginVertical: 24,
  },
  filtrosSection: {
    marginBottom: 24,
  },
  filtroTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#475569",
    marginBottom: 16,
  },
  filtroRow: {
    gap: 12,
    marginBottom: 12,
  },
  filtroGroup: {
    flex: 1,
  },
  filtroLabel: {
    fontSize: 12,
    fontWeight: "600",
    color: "#64748b",
    marginBottom: 6,
  },
  filtroInput: {
    backgroundColor: "#f3f4f6",
    borderWidth: 1,
    borderColor: "#cbd5e1",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: "#1f2937",
  },
  filterButtonsRow: {
    flexDirection: "row",
    gap: 8,
    flexWrap: "wrap",
  },
  filterBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: "#f3f4f6",
    borderWidth: 1,
    borderColor: "#cbd5e1",
  },
  filterBtnActive: {
    backgroundColor: "#2563eb",
    borderColor: "#2563eb",
  },
  filterBtnText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#64748b",
  },
  filterBtnTextActive: {
    color: "#ffffff",
    fontWeight: "700",
  },
  filtroButtonsContainer: {
    flexDirection: "row",
    gap: 12,
    marginTop: 16,
  },
  btnAplicar: {
    flex: 1,
    backgroundColor: "#2563eb",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
  },
  btnAplicarText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
  btnLimpiar: {
    flex: 1,
    backgroundColor: "#f3f4f6",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#cbd5e1",
  },
  btnLimpiarText: {
    color: "#64748b",
    fontWeight: "700",
    fontSize: 14,
  },
  tablaseccion: {
    marginBottom: 24,
  },
  tablaTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#475569",
    marginBottom: 16,
  },
  loadingContainer: {
    alignItems: "center",
    paddingVertical: 40,
  },
  loadingText: {
    color: "#64748b",
    marginTop: 12,
    fontSize: 14,
  },
  emptyContainer: {
    alignItems: "center",
    paddingVertical: 40,
  },
  emptyText: {
    color: "#64748b",
    fontSize: 16,
  },
  accesoItem: {
    backgroundColor: "#f8fafc",
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  accesoHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  accesoLeftContent: {
    flex: 1,
    gap: 8,
  },
  accesoUsuario: {
    fontSize: 14,
    fontWeight: "700",
    color: "#0f172a",
  },
  badge: {
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    alignSelf: "flex-start",
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "600",
  },
  accesoId: {
    fontSize: 12,
    color: "#94a3b8",
  },
  accesoBody: {
    gap: 4,
    marginBottom: 8,
  },
  accesoTabla: {
    fontSize: 13,
    color: "#64748b",
  },
  accesoTiempo: {
    fontSize: 12,
    color: "#94a3b8",
  },
  accesoFooter: {
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: "#e2e8f0",
  },
  accesoDetalles: {
    fontSize: 13,
    color: "#64748b",
  },
  backButton: {
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    backgroundColor: "#fee2e2",
    borderWidth: 2,
    borderColor: "#ef4444",
  },
  backButtonText: {
    color: "#ef4444",
    fontSize: 16,
    fontWeight: "700",
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#ef4444",
    textAlign: "center",
    marginBottom: 12,
  },
  errorText: {
    fontSize: 14,
    color: "#64748b",
    textAlign: "center",
    marginBottom: 24,
  },
  // MODAL
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: "#ffffff",
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingVertical: 24,
    paddingHorizontal: 24,
    maxHeight: "90%",
  },
  modalCloseButton: {
    alignSelf: "flex-end",
    paddingBottom: 12,
  },
  modalCloseText: {
    fontSize: 28,
    color: "#64748b",
    fontWeight: "700",
  },
  modalScroll: {
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: "#0f172a",
    marginBottom: 20,
  },
  modalSection: {
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#e2e8f0",
  },
  modalLabel: {
    fontSize: 12,
    fontWeight: "600",
    color: "#64748b",
    textTransform: "uppercase",
    marginBottom: 6,
  },
  modalValue: {
    fontSize: 14,
    color: "#0f172a",
    fontWeight: "500",
  },
  codeText: {
    fontFamily: "monospace",
    fontSize: 12,
    backgroundColor: "#f3f4f6",
    padding: 8,
    borderRadius: 6,
  },
});
